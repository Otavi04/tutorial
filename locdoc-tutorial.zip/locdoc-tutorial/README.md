# LocDoc · Jornada do paciente

Tutorial interativo estático (HTML, CSS e JS, sem build). Site publicado: https://tutorial.locdoc.com.br

## Deploy na Vercel
- Importe este repositório na Vercel.
- **Root Directory:** `dist`
- **Framework Preset:** Other. Build Command e Install Command vazios.
- Domínio: `tutorial.locdoc.com.br` → CNAME `tutorial` para `cname.vercel-dns.com`.

## Preview de link (Instagram/WhatsApp)
`dist/index.html` usa `og:image` com URL absoluta de `tutorial.locdoc.com.br`.
Se o domínio mudar, atualize `og:url` e `og:image`.
